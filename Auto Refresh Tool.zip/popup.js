// Show toast notification
function showToast(message) {
  const toast = document.getElementById('toast');
  if (toast) {
    toast.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
      toast.classList.remove('show');
    }, 3000);
  }
}

// Update the active tab status
function updateStatus(isActive) {
  const status = document.getElementById('status');
  const statusText = document.getElementById('status-text');
  if (status && statusText) {
    statusText.textContent = isActive ? 'Active' : 'Inactive';
    status.classList.toggle('active', isActive);
  }
}

// Open menu
const menuButton = document.getElementById('menu-button');
if (menuButton) {
  menuButton.addEventListener('click', () => {
    const menu = document.getElementById('menu');
    if (menu) {
      menu.classList.add('active');
      fetchTabList();
    }
  });
}

// Close menu
const closeMenuButton = document.getElementById('close-menu');
if (closeMenuButton) {
  closeMenuButton.addEventListener('click', () => {
    const menu = document.getElementById('menu');
    if (menu) {
      menu.classList.remove('active');
    }
  });
}

// Fetch and display the list of tabs with intervals and favicons
function fetchTabList() {
  const tabList = document.getElementById('tab-list');
  if (tabList) {
    tabList.innerHTML = ''; // Clear the list

    chrome.storage.local.get(['tabs'], (data) => {
      if (data.tabs) {
        Object.entries(data.tabs).forEach(([tabId, tabData]) => {
          const li = document.createElement('li');

          // Create favicon image
          const favicon = document.createElement('img');
          favicon.src = `https://www.google.com/s2/favicons?domain=${new URL(tabData.tabUrl).hostname}`;
          favicon.alt = 'Favicon';
          li.appendChild(favicon);

          // Create URL text
          const urlText = document.createElement('span');
          urlText.className = 'url';
          urlText.textContent = `${tabData.tabUrl} (${tabData.interval / 1000} seconds)`;
          li.appendChild(urlText);

          tabList.appendChild(li);
        });
      }
    });
  }
}

// Restore the interval value and status when the popup loads
document.addEventListener('DOMContentLoaded', () => {
  const intervalInput = document.getElementById('interval');
  if (intervalInput) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        const tabId = tabs[0].id;

        // Get the saved interval for this tab
        chrome.storage.local.get(['tabs'], (data) => {
          if (data.tabs && data.tabs[tabId]) {
            intervalInput.value = data.tabs[tabId].interval / 1000; // Convert to seconds
            updateStatus(true); // Auto-refresh is active
          } else {
            intervalInput.value = 0; // Default value
            updateStatus(false); // Auto-refresh is inactive
          }
        });
      }
    });
  }
});

// Save the interval value and start auto-refresh for the current tab
const startButton = document.getElementById('start');
if (startButton) {
  startButton.addEventListener('click', () => {
    const intervalInput = document.getElementById('interval');
    if (intervalInput) {
      const interval = parseInt(intervalInput.value, 10) * 1000; // Convert to milliseconds

      if (isNaN(interval) || interval <= 0) {
        showToast('Please enter a valid interval (1 to 100000 seconds).');
        return;
      }

      // Get the current active tab
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          const tabId = tabs[0].id;
          const tabUrl = tabs[0].url;

          // Save the interval and tab URL to storage
          chrome.storage.local.get(['tabs'], (data) => {
            const tabsData = data.tabs || {};
            tabsData[tabId] = { interval, tabUrl };
            chrome.storage.local.set({ tabs: tabsData }, () => {
              console.log('Settings saved:', { tabs: tabsData });
              showToast('Auto Refresh Started!');
              updateStatus(true); // Update status to active
            });
          });

          // Send the start command to the background script
          chrome.runtime.sendMessage({ command: 'start', interval, tabId, tabUrl });
        }
      });
    }
  });
}

// Stop auto-refresh for the current active tab and reset the interval value
const stopButton = document.getElementById('stop');
if (stopButton) {
  stopButton.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        const tabId = tabs[0].id;

        // Send the stop command to the background script
        chrome.runtime.sendMessage({ command: 'stop', tabId });

        // Reset the interval value for this tab
        const intervalInput = document.getElementById('interval');
        if (intervalInput) {
          intervalInput.value = 0; // Reset to default
        }

        // Remove the interval for this tab from storage
        chrome.storage.local.get(['tabs'], (data) => {
          const tabsData = data.tabs || {};
          delete tabsData[tabId];
          chrome.storage.local.set({ tabs: tabsData }, () => {
            console.log('Interval cleared for tab:', tabId);
            showToast('Auto Refresh Stopped!');
            updateStatus(false); // Update status to inactive
          });
        });
      }
    });
  });
}

// Reset auto-refresh for all tabs
const resetButton = document.getElementById('reset');
if (resetButton) {
  resetButton.addEventListener('click', () => {
    chrome.runtime.sendMessage({ command: 'reset' });

    // Clear all intervals from storage
    chrome.storage.local.set({ tabs: {} }, () => {
      console.log('All intervals reset.');
      showToast('All auto-refresh tasks reset!');
      updateStatus(false); // Update status to inactive
    });

    // Reset the input field
    const intervalInput = document.getElementById('interval');
    if (intervalInput) {
      intervalInput.value = 0;
    }
  });
}