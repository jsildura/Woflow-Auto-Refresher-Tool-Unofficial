let refreshIntervals = {};

// Reset all intervals when the browser is closed
chrome.windows.onRemoved.addListener(() => {
  for (const tabId in refreshIntervals) {
    clearInterval(refreshIntervals[tabId]);
  }
  refreshIntervals = {};
  chrome.storage.local.set({ tabs: {} });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.command === 'start') {
    const { interval, tabId, tabUrl } = message;

    // Clear any existing interval for this tab
    if (refreshIntervals[tabId]) {
      clearInterval(refreshIntervals[tabId]);
    }

    // Set up the new interval
    refreshIntervals[tabId] = setInterval(() => {
      chrome.tabs.get(tabId, (tab) => {
        if (tab.url === tabUrl) {
          chrome.tabs.reload(tabId);
        }
      });
    }, interval);

    // Save the interval value for this tab
    chrome.storage.local.get(['tabs'], (data) => {
      const tabsData = data.tabs || {};
      tabsData[tabId] = { interval, tabUrl };
      chrome.storage.local.set({ tabs: tabsData });
    });
  } else if (message.command === 'stop') {
    const { tabId } = message;

    // Clear the interval for this tab
    if (refreshIntervals[tabId]) {
      clearInterval(refreshIntervals[tabId]);
      delete refreshIntervals[tabId];
    }

    // Remove the interval for this tab from storage
    chrome.storage.local.get(['tabs'], (data) => {
      const tabsData = data.tabs || {};
      delete tabsData[tabId];
      chrome.storage.local.set({ tabs: tabsData });
    });
  } else if (message.command === 'reset') {
    // Clear all intervals
    for (const tabId in refreshIntervals) {
      clearInterval(refreshIntervals[tabId]);
    }
    refreshIntervals = {};

    // Clear all intervals from storage
    chrome.storage.local.set({ tabs: {} });
  }
});